#!/bin/sh
java -cp "/opt/reqiiresearch/classes:/opt/reqiiresearch/lib/*" -Drs.default.path.home="/opt/reqiiresearch/home" "com.reqiiresearch.bootstrap.ReqiireSearch" start
