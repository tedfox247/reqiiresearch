/*
 * Licensed to Elasticsearch under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package com.reqiiresearch.action.admin.cluster.shards;

import com.reqiiresearch.action.ActionListener;
import com.reqiiresearch.action.support.ActionFilters;
import com.reqiiresearch.action.support.master.TransportMasterNodeReadAction;
import com.reqiiresearch.cluster.ClusterService;
import com.reqiiresearch.cluster.ClusterState;
import com.reqiiresearch.cluster.block.ClusterBlockException;
import com.reqiiresearch.cluster.block.ClusterBlockLevel;
import com.reqiiresearch.cluster.metadata.IndexNameExpressionResolver;
import com.reqiiresearch.cluster.node.DiscoveryNode;
import com.reqiiresearch.cluster.routing.GroupShardsIterator;
import com.reqiiresearch.cluster.routing.ShardIterator;
import com.reqiiresearch.cluster.routing.ShardRouting;
import com.reqiiresearch.common.inject.Inject;
import com.reqiiresearch.common.settings.Settings;
import com.reqiiresearch.threadpool.ThreadPool;
import com.reqiiresearch.transport.TransportService;

import java.util.Map;
import java.util.Set;

import static com.google.common.collect.Sets.newHashSet;

/**
 */
public class TransportClusterSearchShardsAction extends TransportMasterNodeReadAction<ClusterSearchShardsRequest, ClusterSearchShardsResponse> {

    @Inject
    public TransportClusterSearchShardsAction(Settings settings, TransportService transportService, ClusterService clusterService,
                                              ThreadPool threadPool, ActionFilters actionFilters, IndexNameExpressionResolver indexNameExpressionResolver) {
        super(settings, ClusterSearchShardsAction.NAME, transportService, clusterService, threadPool, actionFilters, indexNameExpressionResolver, ClusterSearchShardsRequest.class);
    }

    @Override
    protected String executor() {
        // all in memory work here...
        return ThreadPool.Names.SAME;
    }

    @Override
    protected ClusterBlockException checkBlock(ClusterSearchShardsRequest request, ClusterState state) {
        return state.blocks().indicesBlockedException(ClusterBlockLevel.METADATA_READ, indexNameExpressionResolver.concreteIndices(state, request));
    }

    @Override
    protected ClusterSearchShardsResponse newResponse() {
        return new ClusterSearchShardsResponse();
    }

    @Override
    protected void masterOperation(final ClusterSearchShardsRequest request, final ClusterState state, final ActionListener<ClusterSearchShardsResponse> listener) {
        ClusterState clusterState = clusterService.state();
        String[] concreteIndices = indexNameExpressionResolver.concreteIndices(clusterState, request);
        Map<String, Set<String>> routingMap = indexNameExpressionResolver.resolveSearchRouting(state, request.routing(), request.indices());
        Set<String> nodeIds = newHashSet();
        GroupShardsIterator groupShardsIterator = clusterService.operationRouting().searchShards(clusterState, concreteIndices, routingMap, request.preference());
        ShardRouting shard;
        ClusterSearchShardsGroup[] groupResponses = new ClusterSearchShardsGroup[groupShardsIterator.size()];
        int currentGroup = 0;
        for (ShardIterator shardIt : groupShardsIterator) {
            String index = shardIt.shardId().getIndex();
            int shardId = shardIt.shardId().getId();
            ShardRouting[] shardRoutings = new ShardRouting[shardIt.size()];
            int currentShard = 0;
            shardIt.reset();
            while ((shard = shardIt.nextOrNull()) != null) {
                shardRoutings[currentShard++] = shard;
                nodeIds.add(shard.currentNodeId());
            }
            groupResponses[currentGroup++] = new ClusterSearchShardsGroup(index, shardId, shardRoutings);
        }
        DiscoveryNode[] nodes = new DiscoveryNode[nodeIds.size()];
        int currentNode = 0;
        for (String nodeId : nodeIds) {
            nodes[currentNode++] = clusterState.getNodes().get(nodeId);
        }
        listener.onResponse(new ClusterSearchShardsResponse(groupResponses, nodes));
    }
}
