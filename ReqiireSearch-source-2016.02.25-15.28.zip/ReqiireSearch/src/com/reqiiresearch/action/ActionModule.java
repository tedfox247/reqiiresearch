/*
 * Licensed to Elasticsearch under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package com.reqiiresearch.action;

import com.google.common.collect.Maps;
import com.reqiiresearch.action.admin.cluster.health.ClusterHealthAction;
import com.reqiiresearch.action.admin.cluster.health.TransportClusterHealthAction;
import com.reqiiresearch.action.admin.cluster.node.hotthreads.NodesHotThreadsAction;
import com.reqiiresearch.action.admin.cluster.node.hotthreads.TransportNodesHotThreadsAction;
import com.reqiiresearch.action.admin.cluster.node.info.NodesInfoAction;
import com.reqiiresearch.action.admin.cluster.node.info.TransportNodesInfoAction;
import com.reqiiresearch.action.admin.cluster.node.liveness.TransportLivenessAction;
import com.reqiiresearch.action.admin.cluster.node.stats.NodesStatsAction;
import com.reqiiresearch.action.admin.cluster.node.stats.TransportNodesStatsAction;
import com.reqiiresearch.action.admin.cluster.repositories.delete.DeleteRepositoryAction;
import com.reqiiresearch.action.admin.cluster.repositories.delete.TransportDeleteRepositoryAction;
import com.reqiiresearch.action.admin.cluster.repositories.get.GetRepositoriesAction;
import com.reqiiresearch.action.admin.cluster.repositories.get.TransportGetRepositoriesAction;
import com.reqiiresearch.action.admin.cluster.repositories.put.PutRepositoryAction;
import com.reqiiresearch.action.admin.cluster.repositories.put.TransportPutRepositoryAction;
import com.reqiiresearch.action.admin.cluster.repositories.verify.TransportVerifyRepositoryAction;
import com.reqiiresearch.action.admin.cluster.repositories.verify.VerifyRepositoryAction;
import com.reqiiresearch.action.admin.cluster.reroute.ClusterRerouteAction;
import com.reqiiresearch.action.admin.cluster.reroute.TransportClusterRerouteAction;
import com.reqiiresearch.action.admin.cluster.settings.ClusterUpdateSettingsAction;
import com.reqiiresearch.action.admin.cluster.settings.TransportClusterUpdateSettingsAction;
import com.reqiiresearch.action.admin.cluster.shards.ClusterSearchShardsAction;
import com.reqiiresearch.action.admin.cluster.shards.TransportClusterSearchShardsAction;
import com.reqiiresearch.action.admin.cluster.snapshots.create.CreateSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.create.TransportCreateSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.delete.DeleteSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.delete.TransportDeleteSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.get.GetSnapshotsAction;
import com.reqiiresearch.action.admin.cluster.snapshots.get.TransportGetSnapshotsAction;
import com.reqiiresearch.action.admin.cluster.snapshots.restore.RestoreSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.restore.TransportRestoreSnapshotAction;
import com.reqiiresearch.action.admin.cluster.snapshots.status.SnapshotsStatusAction;
import com.reqiiresearch.action.admin.cluster.snapshots.status.TransportSnapshotsStatusAction;
import com.reqiiresearch.action.admin.cluster.state.ClusterStateAction;
import com.reqiiresearch.action.admin.cluster.state.TransportClusterStateAction;
import com.reqiiresearch.action.admin.cluster.stats.ClusterStatsAction;
import com.reqiiresearch.action.admin.cluster.stats.TransportClusterStatsAction;
import com.reqiiresearch.action.admin.cluster.tasks.PendingClusterTasksAction;
import com.reqiiresearch.action.admin.cluster.tasks.TransportPendingClusterTasksAction;
import com.reqiiresearch.action.admin.indices.alias.IndicesAliasesAction;
import com.reqiiresearch.action.admin.indices.alias.TransportIndicesAliasesAction;
import com.reqiiresearch.action.admin.indices.alias.exists.AliasesExistAction;
import com.reqiiresearch.action.admin.indices.alias.exists.TransportAliasesExistAction;
import com.reqiiresearch.action.admin.indices.alias.get.GetAliasesAction;
import com.reqiiresearch.action.admin.indices.alias.get.TransportGetAliasesAction;
import com.reqiiresearch.action.admin.indices.analyze.AnalyzeAction;
import com.reqiiresearch.action.admin.indices.analyze.TransportAnalyzeAction;
import com.reqiiresearch.action.admin.indices.cache.clear.ClearIndicesCacheAction;
import com.reqiiresearch.action.admin.indices.cache.clear.TransportClearIndicesCacheAction;
import com.reqiiresearch.action.admin.indices.close.CloseIndexAction;
import com.reqiiresearch.action.admin.indices.close.TransportCloseIndexAction;
import com.reqiiresearch.action.admin.indices.create.CreateIndexAction;
import com.reqiiresearch.action.admin.indices.create.TransportCreateIndexAction;
import com.reqiiresearch.action.admin.indices.delete.DeleteIndexAction;
import com.reqiiresearch.action.admin.indices.delete.TransportDeleteIndexAction;
import com.reqiiresearch.action.admin.indices.exists.indices.IndicesExistsAction;
import com.reqiiresearch.action.admin.indices.exists.indices.TransportIndicesExistsAction;
import com.reqiiresearch.action.admin.indices.exists.types.TransportTypesExistsAction;
import com.reqiiresearch.action.admin.indices.exists.types.TypesExistsAction;
import com.reqiiresearch.action.admin.indices.flush.FlushAction;
import com.reqiiresearch.action.admin.indices.flush.TransportFlushAction;
import com.reqiiresearch.action.admin.indices.forcemerge.ForceMergeAction;
import com.reqiiresearch.action.admin.indices.forcemerge.TransportForceMergeAction;
import com.reqiiresearch.action.admin.indices.get.GetIndexAction;
import com.reqiiresearch.action.admin.indices.get.TransportGetIndexAction;
import com.reqiiresearch.action.admin.indices.mapping.get.GetFieldMappingsAction;
import com.reqiiresearch.action.admin.indices.mapping.get.GetMappingsAction;
import com.reqiiresearch.action.admin.indices.mapping.get.TransportGetFieldMappingsAction;
import com.reqiiresearch.action.admin.indices.mapping.get.TransportGetFieldMappingsIndexAction;
import com.reqiiresearch.action.admin.indices.mapping.get.TransportGetMappingsAction;
import com.reqiiresearch.action.admin.indices.mapping.put.PutMappingAction;
import com.reqiiresearch.action.admin.indices.mapping.put.TransportPutMappingAction;
import com.reqiiresearch.action.admin.indices.open.OpenIndexAction;
import com.reqiiresearch.action.admin.indices.open.TransportOpenIndexAction;
import com.reqiiresearch.action.admin.indices.recovery.RecoveryAction;
import com.reqiiresearch.action.admin.indices.recovery.TransportRecoveryAction;
import com.reqiiresearch.action.admin.indices.refresh.RefreshAction;
import com.reqiiresearch.action.admin.indices.refresh.TransportRefreshAction;
import com.reqiiresearch.action.admin.indices.segments.IndicesSegmentsAction;
import com.reqiiresearch.action.admin.indices.segments.TransportIndicesSegmentsAction;
import com.reqiiresearch.action.admin.indices.settings.get.GetSettingsAction;
import com.reqiiresearch.action.admin.indices.settings.get.TransportGetSettingsAction;
import com.reqiiresearch.action.admin.indices.settings.put.TransportUpdateSettingsAction;
import com.reqiiresearch.action.admin.indices.settings.put.UpdateSettingsAction;
import com.reqiiresearch.action.admin.indices.shards.IndicesShardStoresAction;
import com.reqiiresearch.action.admin.indices.shards.TransportIndicesShardStoresAction;
import com.reqiiresearch.action.admin.indices.stats.IndicesStatsAction;
import com.reqiiresearch.action.admin.indices.stats.TransportIndicesStatsAction;
import com.reqiiresearch.action.admin.indices.flush.SyncedFlushAction;
import com.reqiiresearch.action.admin.indices.flush.TransportSyncedFlushAction;
import com.reqiiresearch.action.admin.indices.template.delete.DeleteIndexTemplateAction;
import com.reqiiresearch.action.admin.indices.template.delete.TransportDeleteIndexTemplateAction;
import com.reqiiresearch.action.admin.indices.template.get.GetIndexTemplatesAction;
import com.reqiiresearch.action.admin.indices.template.get.TransportGetIndexTemplatesAction;
import com.reqiiresearch.action.admin.indices.template.put.PutIndexTemplateAction;
import com.reqiiresearch.action.admin.indices.template.put.TransportPutIndexTemplateAction;
import com.reqiiresearch.action.admin.indices.upgrade.get.TransportUpgradeStatusAction;
import com.reqiiresearch.action.admin.indices.upgrade.get.UpgradeStatusAction;
import com.reqiiresearch.action.admin.indices.upgrade.post.TransportUpgradeAction;
import com.reqiiresearch.action.admin.indices.upgrade.post.TransportUpgradeSettingsAction;
import com.reqiiresearch.action.admin.indices.upgrade.post.UpgradeAction;
import com.reqiiresearch.action.admin.indices.upgrade.post.UpgradeSettingsAction;
import com.reqiiresearch.action.admin.indices.validate.query.TransportValidateQueryAction;
import com.reqiiresearch.action.admin.indices.validate.query.ValidateQueryAction;
import com.reqiiresearch.action.admin.cluster.validate.template.RenderSearchTemplateAction;
import com.reqiiresearch.action.admin.cluster.validate.template.TransportRenderSearchTemplateAction;
import com.reqiiresearch.action.admin.indices.warmer.delete.DeleteWarmerAction;
import com.reqiiresearch.action.admin.indices.warmer.delete.TransportDeleteWarmerAction;
import com.reqiiresearch.action.admin.indices.warmer.get.GetWarmersAction;
import com.reqiiresearch.action.admin.indices.warmer.get.TransportGetWarmersAction;
import com.reqiiresearch.action.admin.indices.warmer.put.PutWarmerAction;
import com.reqiiresearch.action.admin.indices.warmer.put.TransportPutWarmerAction;
import com.reqiiresearch.action.bulk.BulkAction;
import com.reqiiresearch.action.bulk.TransportBulkAction;
import com.reqiiresearch.action.bulk.TransportShardBulkAction;
import com.reqiiresearch.action.delete.DeleteAction;
import com.reqiiresearch.action.delete.TransportDeleteAction;
import com.reqiiresearch.action.exists.ExistsAction;
import com.reqiiresearch.action.exists.TransportExistsAction;
import com.reqiiresearch.action.explain.ExplainAction;
import com.reqiiresearch.action.explain.TransportExplainAction;
import com.reqiiresearch.action.fieldstats.FieldStatsAction;
import com.reqiiresearch.action.fieldstats.TransportFieldStatsTransportAction;
import com.reqiiresearch.action.get.GetAction;
import com.reqiiresearch.action.get.MultiGetAction;
import com.reqiiresearch.action.get.TransportGetAction;
import com.reqiiresearch.action.get.TransportMultiGetAction;
import com.reqiiresearch.action.get.TransportShardMultiGetAction;
import com.reqiiresearch.action.index.IndexAction;
import com.reqiiresearch.action.index.TransportIndexAction;
import com.reqiiresearch.action.indexedscripts.delete.DeleteIndexedScriptAction;
import com.reqiiresearch.action.indexedscripts.delete.TransportDeleteIndexedScriptAction;
import com.reqiiresearch.action.indexedscripts.get.GetIndexedScriptAction;
import com.reqiiresearch.action.indexedscripts.get.TransportGetIndexedScriptAction;
import com.reqiiresearch.action.indexedscripts.put.PutIndexedScriptAction;
import com.reqiiresearch.action.indexedscripts.put.TransportPutIndexedScriptAction;
import com.reqiiresearch.action.percolate.MultiPercolateAction;
import com.reqiiresearch.action.percolate.PercolateAction;
import com.reqiiresearch.action.percolate.TransportMultiPercolateAction;
import com.reqiiresearch.action.percolate.TransportPercolateAction;
import com.reqiiresearch.action.percolate.TransportShardMultiPercolateAction;
import com.reqiiresearch.action.search.ClearScrollAction;
import com.reqiiresearch.action.search.MultiSearchAction;
import com.reqiiresearch.action.search.SearchAction;
import com.reqiiresearch.action.search.SearchScrollAction;
import com.reqiiresearch.action.search.TransportClearScrollAction;
import com.reqiiresearch.action.search.TransportMultiSearchAction;
import com.reqiiresearch.action.search.TransportSearchAction;
import com.reqiiresearch.action.search.TransportSearchScrollAction;
import com.reqiiresearch.action.search.type.TransportSearchDfsQueryAndFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchDfsQueryThenFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchQueryAndFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchQueryThenFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchScanAction;
import com.reqiiresearch.action.search.type.TransportSearchScrollQueryAndFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchScrollQueryThenFetchAction;
import com.reqiiresearch.action.search.type.TransportSearchScrollScanAction;
import com.reqiiresearch.action.suggest.SuggestAction;
import com.reqiiresearch.action.suggest.TransportSuggestAction;
import com.reqiiresearch.action.support.ActionFilter;
import com.reqiiresearch.action.support.ActionFilters;
import com.reqiiresearch.action.support.AutoCreateIndex;
import com.reqiiresearch.action.support.DestructiveOperations;
import com.reqiiresearch.action.support.TransportAction;
import com.reqiiresearch.action.termvectors.MultiTermVectorsAction;
import com.reqiiresearch.action.termvectors.TermVectorsAction;
import com.reqiiresearch.action.termvectors.TransportMultiTermVectorsAction;
import com.reqiiresearch.action.termvectors.TransportShardMultiTermsVectorAction;
import com.reqiiresearch.action.termvectors.TransportTermVectorsAction;
import com.reqiiresearch.action.termvectors.dfs.TransportDfsOnlyAction;
import com.reqiiresearch.action.update.TransportUpdateAction;
import com.reqiiresearch.action.update.UpdateAction;
import com.reqiiresearch.common.inject.AbstractModule;
import com.reqiiresearch.common.inject.multibindings.MapBinder;
import com.reqiiresearch.common.inject.multibindings.Multibinder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 */
public class ActionModule extends AbstractModule {

    private final Map<String, ActionEntry> actions = Maps.newHashMap();
    private final List<Class<? extends ActionFilter>> actionFilters = new ArrayList<>();

    static class ActionEntry<Request extends ActionRequest, Response extends ActionResponse> {
        public final GenericAction<Request, Response> action;
        public final Class<? extends TransportAction<Request, Response>> transportAction;
        public final Class[] supportTransportActions;

        ActionEntry(GenericAction<Request, Response> action, Class<? extends TransportAction<Request, Response>> transportAction, Class... supportTransportActions) {
            this.action = action;
            this.transportAction = transportAction;
            this.supportTransportActions = supportTransportActions;
        }


    }

    private final boolean proxy;

    public ActionModule(boolean proxy) {
        this.proxy = proxy;
    }

    /**
     * Registers an action.
     *
     * @param action                  The action type.
     * @param transportAction         The transport action implementing the actual action.
     * @param supportTransportActions Any support actions that are needed by the transport action.
     * @param <Request>               The request type.
     * @param <Response>              The response type.
     */
    public <Request extends ActionRequest, Response extends ActionResponse> void registerAction(GenericAction<Request, Response> action, Class<? extends TransportAction<Request, Response>> transportAction, Class... supportTransportActions) {
        actions.put(action.name(), new ActionEntry<>(action, transportAction, supportTransportActions));
    }

    public ActionModule registerFilter(Class<? extends ActionFilter> actionFilter) {
        actionFilters.add(actionFilter);
        return this;
    }

    @Override
    protected void configure() {

        Multibinder<ActionFilter> actionFilterMultibinder = Multibinder.newSetBinder(binder(), ActionFilter.class);
        for (Class<? extends ActionFilter> actionFilter : actionFilters) {
            actionFilterMultibinder.addBinding().to(actionFilter);
        }
        bind(ActionFilters.class).asEagerSingleton();
        bind(AutoCreateIndex.class).asEagerSingleton();
        bind(DestructiveOperations.class).asEagerSingleton();
        registerAction(NodesInfoAction.INSTANCE, TransportNodesInfoAction.class);
        registerAction(NodesStatsAction.INSTANCE, TransportNodesStatsAction.class);
        registerAction(NodesHotThreadsAction.INSTANCE, TransportNodesHotThreadsAction.class);

        registerAction(ClusterStatsAction.INSTANCE, TransportClusterStatsAction.class);
        registerAction(ClusterStateAction.INSTANCE, TransportClusterStateAction.class);
        registerAction(ClusterHealthAction.INSTANCE, TransportClusterHealthAction.class);
        registerAction(ClusterUpdateSettingsAction.INSTANCE, TransportClusterUpdateSettingsAction.class);
        registerAction(ClusterRerouteAction.INSTANCE, TransportClusterRerouteAction.class);
        registerAction(ClusterSearchShardsAction.INSTANCE, TransportClusterSearchShardsAction.class);
        registerAction(PendingClusterTasksAction.INSTANCE, TransportPendingClusterTasksAction.class);
        registerAction(PutRepositoryAction.INSTANCE, TransportPutRepositoryAction.class);
        registerAction(GetRepositoriesAction.INSTANCE, TransportGetRepositoriesAction.class);
        registerAction(DeleteRepositoryAction.INSTANCE, TransportDeleteRepositoryAction.class);
        registerAction(VerifyRepositoryAction.INSTANCE, TransportVerifyRepositoryAction.class);
        registerAction(GetSnapshotsAction.INSTANCE, TransportGetSnapshotsAction.class);
        registerAction(DeleteSnapshotAction.INSTANCE, TransportDeleteSnapshotAction.class);
        registerAction(CreateSnapshotAction.INSTANCE, TransportCreateSnapshotAction.class);
        registerAction(RestoreSnapshotAction.INSTANCE, TransportRestoreSnapshotAction.class);
        registerAction(SnapshotsStatusAction.INSTANCE, TransportSnapshotsStatusAction.class);

        registerAction(IndicesStatsAction.INSTANCE, TransportIndicesStatsAction.class);
        registerAction(IndicesSegmentsAction.INSTANCE, TransportIndicesSegmentsAction.class);
        registerAction(IndicesShardStoresAction.INSTANCE, TransportIndicesShardStoresAction.class);
        registerAction(CreateIndexAction.INSTANCE, TransportCreateIndexAction.class);
        registerAction(DeleteIndexAction.INSTANCE, TransportDeleteIndexAction.class);
        registerAction(GetIndexAction.INSTANCE, TransportGetIndexAction.class);
        registerAction(OpenIndexAction.INSTANCE, TransportOpenIndexAction.class);
        registerAction(CloseIndexAction.INSTANCE, TransportCloseIndexAction.class);
        registerAction(IndicesExistsAction.INSTANCE, TransportIndicesExistsAction.class);
        registerAction(TypesExistsAction.INSTANCE, TransportTypesExistsAction.class);
        registerAction(GetMappingsAction.INSTANCE, TransportGetMappingsAction.class);
        registerAction(GetFieldMappingsAction.INSTANCE, TransportGetFieldMappingsAction.class, TransportGetFieldMappingsIndexAction.class);
        registerAction(PutMappingAction.INSTANCE, TransportPutMappingAction.class);
        registerAction(IndicesAliasesAction.INSTANCE, TransportIndicesAliasesAction.class);
        registerAction(UpdateSettingsAction.INSTANCE, TransportUpdateSettingsAction.class);
        registerAction(AnalyzeAction.INSTANCE, TransportAnalyzeAction.class);
        registerAction(PutIndexTemplateAction.INSTANCE, TransportPutIndexTemplateAction.class);
        registerAction(GetIndexTemplatesAction.INSTANCE, TransportGetIndexTemplatesAction.class);
        registerAction(DeleteIndexTemplateAction.INSTANCE, TransportDeleteIndexTemplateAction.class);
        registerAction(ValidateQueryAction.INSTANCE, TransportValidateQueryAction.class);
        registerAction(RefreshAction.INSTANCE, TransportRefreshAction.class);
        registerAction(FlushAction.INSTANCE, TransportFlushAction.class);
        registerAction(SyncedFlushAction.INSTANCE, TransportSyncedFlushAction.class);
        registerAction(ForceMergeAction.INSTANCE, TransportForceMergeAction.class);
        registerAction(UpgradeAction.INSTANCE, TransportUpgradeAction.class);
        registerAction(UpgradeStatusAction.INSTANCE, TransportUpgradeStatusAction.class);
        registerAction(UpgradeSettingsAction.INSTANCE, TransportUpgradeSettingsAction.class);
        registerAction(ClearIndicesCacheAction.INSTANCE, TransportClearIndicesCacheAction.class);
        registerAction(PutWarmerAction.INSTANCE, TransportPutWarmerAction.class);
        registerAction(DeleteWarmerAction.INSTANCE, TransportDeleteWarmerAction.class);
        registerAction(GetWarmersAction.INSTANCE, TransportGetWarmersAction.class);
        registerAction(GetAliasesAction.INSTANCE, TransportGetAliasesAction.class);
        registerAction(AliasesExistAction.INSTANCE, TransportAliasesExistAction.class);
        registerAction(GetSettingsAction.INSTANCE, TransportGetSettingsAction.class);

        registerAction(IndexAction.INSTANCE, TransportIndexAction.class);
        registerAction(GetAction.INSTANCE, TransportGetAction.class);
        registerAction(TermVectorsAction.INSTANCE, TransportTermVectorsAction.class,
                TransportDfsOnlyAction.class);
        registerAction(MultiTermVectorsAction.INSTANCE, TransportMultiTermVectorsAction.class,
                TransportShardMultiTermsVectorAction.class);
        registerAction(DeleteAction.INSTANCE, TransportDeleteAction.class);
        registerAction(ExistsAction.INSTANCE, TransportExistsAction.class);
        registerAction(SuggestAction.INSTANCE, TransportSuggestAction.class);
        registerAction(UpdateAction.INSTANCE, TransportUpdateAction.class);
        registerAction(MultiGetAction.INSTANCE, TransportMultiGetAction.class,
                TransportShardMultiGetAction.class);
        registerAction(BulkAction.INSTANCE, TransportBulkAction.class,
                TransportShardBulkAction.class);
        registerAction(SearchAction.INSTANCE, TransportSearchAction.class,
                TransportSearchDfsQueryThenFetchAction.class,
                TransportSearchQueryThenFetchAction.class,
                TransportSearchDfsQueryAndFetchAction.class,
                TransportSearchQueryAndFetchAction.class,
                TransportSearchScanAction.class
        );
        registerAction(SearchScrollAction.INSTANCE, TransportSearchScrollAction.class,
                TransportSearchScrollScanAction.class,
                TransportSearchScrollQueryThenFetchAction.class,
                TransportSearchScrollQueryAndFetchAction.class
        );
        registerAction(MultiSearchAction.INSTANCE, TransportMultiSearchAction.class);
        registerAction(PercolateAction.INSTANCE, TransportPercolateAction.class);
        registerAction(MultiPercolateAction.INSTANCE, TransportMultiPercolateAction.class, TransportShardMultiPercolateAction.class);
        registerAction(ExplainAction.INSTANCE, TransportExplainAction.class);
        registerAction(ClearScrollAction.INSTANCE, TransportClearScrollAction.class);
        registerAction(RecoveryAction.INSTANCE, TransportRecoveryAction.class);
        registerAction(RenderSearchTemplateAction.INSTANCE, TransportRenderSearchTemplateAction.class);

        //Indexed scripts
        registerAction(PutIndexedScriptAction.INSTANCE, TransportPutIndexedScriptAction.class);
        registerAction(GetIndexedScriptAction.INSTANCE, TransportGetIndexedScriptAction.class);
        registerAction(DeleteIndexedScriptAction.INSTANCE, TransportDeleteIndexedScriptAction.class);

        registerAction(FieldStatsAction.INSTANCE, TransportFieldStatsTransportAction.class);

        // register Name -> GenericAction Map that can be injected to instances.
        MapBinder<String, GenericAction> actionsBinder
                = MapBinder.newMapBinder(binder(), String.class, GenericAction.class);

        for (Map.Entry<String, ActionEntry> entry : actions.entrySet()) {
            actionsBinder.addBinding(entry.getKey()).toInstance(entry.getValue().action);
        }
        // register GenericAction -> transportAction Map that can be injected to instances.
        // also register any supporting classes
        if (!proxy) {
            bind(TransportLivenessAction.class).asEagerSingleton();
            MapBinder<GenericAction, TransportAction> transportActionsBinder
                    = MapBinder.newMapBinder(binder(), GenericAction.class, TransportAction.class);
            for (Map.Entry<String, ActionEntry> entry : actions.entrySet()) {
                // bind the action as eager singleton, so the map binder one will reuse it
                bind(entry.getValue().transportAction).asEagerSingleton();
                transportActionsBinder.addBinding(entry.getValue().action).to(entry.getValue().transportAction).asEagerSingleton();
                for (Class supportAction : entry.getValue().supportTransportActions) {
                    bind(supportAction).asEagerSingleton();
                }
            }
        }
    }
}
